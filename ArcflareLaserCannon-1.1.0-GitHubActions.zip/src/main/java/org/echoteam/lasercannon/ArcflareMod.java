package org.echoteam.lasercannon;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(ArcflareMod.MOD_ID)
public final class ArcflareMod {
    public static final String MOD_ID = "lasercannon";
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredItem<LaserCannonItem> LASER_CANNON = ITEMS.registerItem(
        "laser_cannon", LaserCannonItem::new,
        new Item.Properties().durability(LaserCannonItem.MAX_ENERGY).stacksTo(1)
    );

    public ArcflareMod(IEventBus modBus) {
        ITEMS.register(modBus);
        modBus.addListener(FireControlPayload::register);
        modBus.addListener(this::addCreativeItems);
    }

    private void addCreativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(LASER_CANNON.get());
        }
    }
}
