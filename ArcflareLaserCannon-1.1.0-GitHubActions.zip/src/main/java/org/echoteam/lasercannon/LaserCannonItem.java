package org.echoteam.lasercannon;

import java.util.Optional;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Arcflare 1.1: LMB (also RMB) hold to fire after wind-up, 10 HP/s, 30-block range. */
public final class LaserCannonItem extends Item {
    public static final int MAX_ENERGY = 400;
    public static final int ENERGY_PER_TICK = 2; // 10 seconds of continuous fire at full battery.
    public static final int WINDUP_TICKS = 24;
    public static final double RANGE = 30.0;
    private static final int USE_TICKS = 72000;
    private static final float DAMAGE_EACH_10_TICKS = 5.0f; // 5 HP / 0.5s = 10 HP/s.
    private static final DustParticleOptions RED = new DustParticleOptions(0xFF2634, 0.75f);
    private static final DustParticleOptions CYAN = new DustParticleOptions(0x95EFFF, 0.95f);

    public LaserCannonItem(Properties properties) {
        super(properties);
    }

    public static int getEnergy(ItemStack stack) {
        return Math.max(0, MAX_ENERGY - stack.getDamageValue());
    }

    // RMB remains a supported alternative. LMB is handled via FireControlPayload.
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (getEnergy(stack) < ENERGY_PER_TICK) {
            if (!level.isClientSide()) {
                player.displayClientMessage(Component.translatable("message.lasercannon.no_energy"), true);
            }
            return InteractionResult.FAIL;
        }
        player.startUsingItem(hand);
        if (!level.isClientSide()) {
            level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE,
                    SoundSource.PLAYERS, 0.32f, 1.6f);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return USE_TICKS;
    }

    @Override
    public ItemUseAnimation getUseAnimation(ItemStack stack) {
        return ItemUseAnimation.NONE;
    }

    // Even when the gun remains selected, idle energy is restored on the server.
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide() || !(entity instanceof Player player)) return;
        if (player.isUsingItem() && player.getUseItem() == stack) return;
        // One energy per 2 ticks, 40s to recharge fully from empty.
        if (level.getGameTime() % 2 == 0 && stack.getDamageValue() > 0) {
            stack.setDamageValue(stack.getDamageValue() - 1);
        }
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (!(level instanceof ServerLevel server) || !(entity instanceof Player player)) return;
        int elapsed = USE_TICKS - remaining;
        if (elapsed < WINDUP_TICKS) {
            if (elapsed >= 0 && elapsed % 3 == 0) chargingEffect(server, player, elapsed);
            return;
        }

        if (getEnergy(stack) < ENERGY_PER_TICK) {
            player.stopUsingItem();
            server.playSound(null, player.blockPosition(), SoundEvents.BEACON_DEACTIVATE,
                    SoundSource.PLAYERS, 0.55f, 0.75f);
            return;
        }
        stack.setDamageValue(Math.min(MAX_ENERGY, stack.getDamageValue() + ENERGY_PER_TICK));
        boolean damageTick = (elapsed - WINDUP_TICKS) % 10 == 0;
        fireTick(server, player, damageTick, elapsed);
    }

    public static Vec3 rightVector(Vec3 forward) {
        Vec3 right = forward.cross(new Vec3(0, 1, 0));
        if (right.lengthSqr() < 1e-5) right = forward.cross(new Vec3(1, 0, 0));
        return right.normalize();
    }

    /** Common target acquisition for both server damage and client visual endpoints. */
    public static BeamHit trace(Level level, Player player) {
        Vec3 eye = player.getEyePosition();
        Vec3 dir = player.getLookAngle().normalize();
        Vec3 maxEnd = eye.add(dir.scale(RANGE));
        BlockHitResult block = level.clip(new ClipContext(
                eye, maxEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 end = block.getType() == HitResult.Type.MISS ? maxEnd : block.getLocation();
        LivingEntity nearest = null;
        double nearestDist = eye.distanceToSqr(end);
        for (LivingEntity living : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(eye, end).inflate(1.0),
                candidate -> candidate != player && candidate.isAlive())) {
            Optional<Vec3> clip = living.getBoundingBox().inflate(0.18).clip(eye, end);
            if (clip.isPresent()) {
                double dist = eye.distanceToSqr(clip.get());
                if (dist < nearestDist) {
                    nearest = living;
                    nearestDist = dist;
                }
            }
        }
        if (nearest != null) end = eye.add(dir.scale(Math.sqrt(nearestDist)));
        return new BeamHit(eye, end, nearest);
    }

    public record BeamHit(Vec3 start, Vec3 end, LivingEntity entity) {}

    private static void chargingEffect(ServerLevel level, Player player, int elapsed) {
        Vec3 forward = player.getLookAngle().normalize();
        Vec3 side = rightVector(forward);
        Vec3 up = side.cross(forward).normalize();
        Vec3 muzzle = player.getEyePosition().add(forward.scale(0.95)).add(side.scale(0.2));
        double slide = Math.min(1.0, elapsed / (double) WINDUP_TICKS);
        for (int sign : new int[]{-1, 1}) {
            Vec3 emitter = muzzle.add(up.scale(sign * (0.24 + 0.26 * slide)));
            for (int i = 0; i < 4; i++) {
                Vec3 p = emitter.lerp(muzzle, i / 3.0);
                level.sendParticles(RED, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
        }
        for (int i = 0; i < 5; i++) {
            double a = elapsed * 0.48 + i * Math.PI * 2.0 / 5;
            Vec3 p = muzzle.add(side.scale(0.29 * Math.cos(a))).add(up.scale(0.29 * Math.sin(a)));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        level.sendParticles(CYAN, muzzle.x, muzzle.y, muzzle.z, 1, 0, 0, 0, 0);
    }

    private static void fireTick(ServerLevel level, Player player, boolean damageTick, int tick) {
        BeamHit ray = trace(level, player);
        if (damageTick && ray.entity() != null) {
            // A 5-HP hit every 10 ticks avoids the standard hurt-invulnerability issue.
            ray.entity().hurt(level.damageSources().magic(), DAMAGE_EACH_10_TICKS);
        }
        // Sparse server particles let other players see the beam even without client renderer.
        if (tick % 2 == 0) {
            Vec3 diff = ray.end().subtract(ray.start());
            double length = diff.length();
            Vec3 dir = diff.normalize();
            for (double d = 0.9; d < length; d += 1.1) {
                Vec3 p = ray.start().add(dir.scale(d));
                level.sendParticles(CYAN, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK, ray.end().x, ray.end().y, ray.end().z,
                    2, 0.1, 0.1, 0.1, 0.02);
        }
        if (tick % 16 == 0) {
            level.playSound(null, player.blockPosition(), SoundEvents.BEACON_AMBIENT,
                    SoundSource.PLAYERS, 0.48f, 2.0f);
        }
    }
}
