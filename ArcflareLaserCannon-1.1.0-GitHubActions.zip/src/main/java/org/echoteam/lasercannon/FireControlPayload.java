package org.echoteam.lasercannon;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/** Client -> server: press/release of the attack key while holding the cannon. */
public record FireControlPayload(boolean pressed) implements CustomPacketPayload {
    public static final Type<FireControlPayload> TYPE = new Type<>(
        ResourceLocation.fromNamespaceAndPath(ArcflareMod.MOD_ID, "fire_control"));

    public static final StreamCodec<RegistryFriendlyByteBuf, FireControlPayload> STREAM_CODEC =
        StreamCodec.of(FireControlPayload::encode, FireControlPayload::decode);

    private static void encode(RegistryFriendlyByteBuf buf, FireControlPayload packet) {
        buf.writeBoolean(packet.pressed());
    }

    private static FireControlPayload decode(RegistryFriendlyByteBuf buf) {
        return new FireControlPayload(buf.readBoolean());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToServer(TYPE, STREAM_CODEC, (message, context) -> {
            if (!(context.player() instanceof ServerPlayer player)) return;
            if (message.pressed()) {
                if (player.getMainHandItem().is(ArcflareMod.LASER_CANNON.get())
                        && !player.isUsingItem()
                        && LaserCannonItem.getEnergy(player.getMainHandItem()) > 0) {
                    player.startUsingItem(InteractionHand.MAIN_HAND);
                }
            } else if (player.isUsingItem()
                    && player.getUseItem().is(ArcflareMod.LASER_CANNON.get())) {
                player.stopUsingItem();
            }
        });
    }
}
