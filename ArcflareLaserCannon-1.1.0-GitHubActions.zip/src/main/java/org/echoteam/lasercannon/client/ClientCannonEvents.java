package org.echoteam.lasercannon.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.echoteam.lasercannon.ArcflareMod;
import org.echoteam.lasercannon.FireControlPayload;
import org.echoteam.lasercannon.LaserCannonItem;
import org.joml.Matrix4f;

/** LMB control and realtime geometry beam for the local player. */
@EventBusSubscriber(modid = ArcflareMod.MOD_ID, value = Dist.CLIENT)
public final class ClientCannonEvents {
    private static boolean lastPressed = false;
    private static int clientHoldTicks = 0;
    private static boolean localPreviewActive = false;

    private ClientCannonEvents() {}

    @SubscribeEvent
    public static void onAttack(InputEvent.InteractionKeyMappingTriggered event) {
        Minecraft mc = Minecraft.getInstance();
        if (event.isAttack() && mc.player != null && mc.player.getMainHandItem().is(ArcflareMod.LASER_CANNON.get())) {
            event.setCanceled(true); // Prevent normal punching/breaking while firing.
            event.setSwingHand(false);
        }
    }

    @SubscribeEvent
    public static void clientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        boolean active = mc.player != null && mc.screen == null && mc.level != null
                && mc.options.keyAttack.isDown()
                && mc.player.getMainHandItem().is(ArcflareMod.LASER_CANNON.get())
                && LaserCannonItem.getEnergy(mc.player.getMainHandItem()) > 0;

        if (active != lastPressed) {
            if (mc.getConnection() != null) {
                PacketDistributor.sendToServer(new FireControlPayload(active));
            }
            lastPressed = active;
            clientHoldTicks = 0;
        }
        if (active) {
            clientHoldTicks++;
            if (!mc.player.isUsingItem()) {
                mc.player.startUsingItem(InteractionHand.MAIN_HAND);
                localPreviewActive = true;
            }
        } else {
            clientHoldTicks = 0;
            if (localPreviewActive && mc.player != null && mc.player.isUsingItem()
                    && mc.player.getUseItem().is(ArcflareMod.LASER_CANNON.get())) {
                mc.player.stopUsingItem();
            }
            localPreviewActive = false;
        }
    }

    @SubscribeEvent
    public static void renderBeam(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || event.getPoseStack() == null) return;
        ItemStack held = mc.player.getMainHandItem();
        if (!held.is(ArcflareMod.LASER_CANNON.get())) return;
        boolean leftFiring = lastPressed && clientHoldTicks >= LaserCannonItem.WINDUP_TICKS;
        boolean rightFiring = mc.player.isUsingItem() && mc.player.getUseItem() == held
                && mc.player.getTicksUsingItem() >= LaserCannonItem.WINDUP_TICKS;
        if (!(leftFiring || rightFiring) || LaserCannonItem.getEnergy(held) <= 0) return;

        LaserCannonItem.BeamHit hit = LaserCannonItem.trace(mc.level, mc.player);
        Vec3 dir = hit.end().subtract(hit.start()).normalize();
        Vec3 side = LaserCannonItem.rightVector(dir);
        Vec3 up = side.cross(dir).normalize();
        // Move beginning slightly outside the eye so the full beam doesn't obscure the screen.
        Vec3 begin = hit.start().add(dir.scale(0.8)).add(side.scale(0.12));
        double length = Math.max(0.0, hit.end().subtract(begin).length());
        if (length <= 0.15) return;

        PoseStack poses = event.getPoseStack();
        poses.pushPose();
        Vec3 camera = event.getCamera().getPosition();
        poses.translate(-camera.x, -camera.y, -camera.z);
        Matrix4f matrix = poses.last().pose();
        RenderType type = RenderType.lightning(); // POSITION_COLOR, additive-style translucent geometry.
        VertexConsumer vc = mc.renderBuffers().bufferSource().getBuffer(type);
        float spin = (float) ((mc.level.getGameTime() + event.getPartialTick().getGameTimeDeltaPartialTick(false)) * 0.19);
        // Cross-sectional true 3D: outer cyan tube, inner white tube and rotating cyan filaments.
        cylinder(vc, matrix, begin, dir, side, up, length, 0.145f, 16, spin,
                60, 190, 255, 45);
        cylinder(vc, matrix, begin, dir, side, up, length, 0.066f, 12, spin * 0.5f,
                225, 250, 255, 170);
        filament(vc, matrix, begin, dir, side, up, length, spin);
        mc.renderBuffers().bufferSource().endBatch(type);
        poses.popPose();
    }

    private static void cylinder(VertexConsumer vc, Matrix4f mat, Vec3 origin, Vec3 axis,
            Vec3 right, Vec3 up, double len, float radius, int sides, float spin,
            int r, int g, int b, int alpha) {
        int segments = Math.max(2, (int) Math.ceil(len / 1.5));
        for (int segment = 0; segment < segments; segment++) {
            double t1 = len * segment / segments;
            double t2 = len * (segment + 1) / segments;
            for (int n = 0; n < sides; n++) {
                double a1 = spin + n * Math.PI * 2 / sides;
                double a2 = spin + (n + 1) * Math.PI * 2 / sides;
                Vec3 a = point(origin, axis, right, up, t1, radius, a1);
                Vec3 bb = point(origin, axis, right, up, t1, radius, a2);
                Vec3 c = point(origin, axis, right, up, t2, radius, a2);
                Vec3 d = point(origin, axis, right, up, t2, radius, a1);
                put(vc,mat,a,r,g,b,alpha);
                put(vc,mat,bb,r,g,b,alpha);
                put(vc,mat,c,r,g,b,alpha);
                put(vc,mat,d,r,g,b,alpha);
            }
        }
    }

    private static void filament(VertexConsumer vc, Matrix4f mat, Vec3 origin, Vec3 axis,
            Vec3 right, Vec3 up, double len, float spin) {
        for (int strand = 0; strand < 2; strand++) {
            int segments = Math.max(4, (int) Math.ceil(len * 2));
            for (int i = 0; i < segments; i++) {
                double d1 = len * i / segments;
                double d2 = len * (i + 1) / segments;
                double a1 = spin + d1 * 2.3 + strand * Math.PI;
                double a2 = spin + d2 * 2.3 + strand * Math.PI;
                Vec3 a = point(origin, axis, right, up, d1, 0.19f, a1);
                Vec3 b = point(origin, axis, right, up, d1, 0.19f, a1 + 0.15);
                Vec3 c = point(origin, axis, right, up, d2, 0.19f, a2 + 0.15);
                Vec3 d = point(origin, axis, right, up, d2, 0.19f, a2);
                put(vc,mat,a,120,225,255,95);
                put(vc,mat,b,120,225,255,95);
                put(vc,mat,c,120,225,255,95);
                put(vc,mat,d,120,225,255,95);
            }
        }
    }

    private static Vec3 point(Vec3 o, Vec3 a, Vec3 r, Vec3 u, double distance, float radius, double angle) {
        return o.add(a.scale(distance)).add(r.scale(Math.cos(angle) * radius)).add(u.scale(Math.sin(angle) * radius));
    }

    private static void put(VertexConsumer vc, Matrix4f mat, Vec3 p, int r, int g, int b, int a) {
        vc.addVertex(mat, (float)p.x, (float)p.y, (float)p.z).setColor(r,g,b,a);
    }
}
