@echo off
call "%~dp0gradlew.bat" build --no-daemon
if errorlevel 1 (
  echo.
  echo [Arcflare] Build failed. Copy the entire console output for debugging.
  pause
  exit /b 1
)
echo.
echo [Arcflare] Finished: build\libs\lasercannon-1.1.0.jar
pause
