@echo off
setlocal
set "ROOT=%~dp0"
set "WRAPPER=%ROOT%gradle\wrapper\gradle-wrapper.jar"
if not exist "%WRAPPER%" (
    echo [Arcflare] Downloading official Gradle Wrapper JAR on first run...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/NeoForgeMDKs/MDK-1.21.4-ModDevGradle/main/gradle/wrapper/gradle-wrapper.jar' -OutFile '%WRAPPER%'"
    if errorlevel 1 (
        echo [ERROR] Could not download official Gradle Wrapper JAR. Internet access is required.
        exit /b 1
    )
)
if defined JAVA_HOME (
    set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
) else (
    set "JAVA_EXE=java.exe"
)
"%JAVA_EXE%" -Dorg.gradle.appname=gradlew -classpath "%WRAPPER%" org.gradle.wrapper.GradleWrapperMain %*
exit /b %ERRORLEVEL%
